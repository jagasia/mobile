package com.model;

import javax.validation.constraints.Positive;

import org.springframework.lang.NonNull;

//pojo class with required attributes,getters and setters 
public class Order {
	@NonNull
	private String customerName;
	@NonNull
	private String contactNumber;
	private String productName;
	@Positive
	private int quantity;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
