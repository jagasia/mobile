package com.service;

import org.springframework.stereotype.Service;

import com.model.Order;

//use appropriate annotation to configure BillService as a Service
@Service
public class BillService {
	
	//calculate the totalCost and return the cost
	public double calculateTotalCost(Order order) {
		double price=0.0;
		double temp = 0.0;
		double cost=0.0;
		// fill the code
		if(order.getProductName().equals("HeadPhone")) {
			price=450.0;
		}
		else if(order.getProductName().equals("TravelAdapter")) {
			price=1000.0;
		}
		else if(order.getProductName().equals("MemoryCard")){
			price=300.0;
		}
		else if(order.getProductName().equals("PenDrive")) {
			price=650.0;
		}
		else if(order.getProductName().equals("USBCable")) {
			price=800.0;
		}
		
		temp=(double) order.getQuantity()*price;
		cost=temp+(temp*3.0/100.0);
		return cost;
	}

}
